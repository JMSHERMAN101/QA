string1 = "cheese is like food sometimes"

list1 = ["cat","dog","penguin","key","nose"]

print(len(string1))

print(len(list1))