varnum1 = 4
varnum2 = 7

print(varnum1 + varnum2)
print(varnum1 - varnum2)
print(varnum1 * varnum2)
print(varnum1 // varnum2)

varnum4 = 6
varnum3 = 10
print(varnum3 / varnum4)   # True Division
print(varnum3 // varnum4)  # Floor Division
print(varnum3 % varnum4)  #  Modulo

print((3 - 2) * 10)   #  Brackets for order

print(2**5)