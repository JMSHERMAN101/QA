#  print()

print("text")

# sorted()

sortedlistvar = sorted(["z","p","a"])

# round()
roundedfloatvar = round(2.67897)

# input

inputstringvar = input("Type something in")

list1 = []
list1.append("cat")
list1.append("dog")

strvar1 = " ,"
strvar1.join(list1)

