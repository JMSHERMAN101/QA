from random import randint
from leonsfuncs import sorted as leonsort


print(leonsort())

list1 = ["sheep","cat","dog"]

print(sorted(list1))