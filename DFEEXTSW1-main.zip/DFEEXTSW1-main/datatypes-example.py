# Pet
name = "Pep Guardogiola"
age = 3
bark = True
tweet = False

print("My pet is called"+ name+ ", He is"+ str(age) + "years old.")
print("Statement:" + name + "barks." + str(bark))
print("Statement:" + name + "tweets." + str(tweet))