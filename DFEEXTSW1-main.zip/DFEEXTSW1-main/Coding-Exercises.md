# Python Exercises available on the web

## Variables, lists, tuples and dictionaries

<https://holypython.com/beginner-python-lessons/>

<https://holypython.com/beginner-python-exercises/exercise-6-python-lists/>

<https://holypython.com/beginner-python-exercises/exercise-8-python-dictionaries/>

## Conditionals and Loops

<https://www.w3resource.com/python-exercises/python-conditional-statements-and-loop-exercises.php>

## Functions

<https://www.w3resource.com/python-exercises/python-functions-exercises.php>

## Classes

<https://github.com/Crush-Steelpunch/DFEEXTSW1/blob/main/Class/Classes-Exercises.md>

