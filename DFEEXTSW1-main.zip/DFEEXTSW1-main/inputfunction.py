var1 = input("Type something in: ")
print(var1)


numbervar1 = int(input("Type in a number"))
print(40 + numbervar1)
