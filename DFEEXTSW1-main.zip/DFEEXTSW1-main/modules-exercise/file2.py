#Create 2 new Python files. 
# In one file, write a function 
# that will generate a number between 
# 1 and 6. 
# Make this a module called dice.

# In the second file, use the dice module 
# to simulate throwing 2 dice
# and print the values you get from 
# the dice.

#
import dice
import pdb
pdb.set_trace()

print("Die 1: " + str(dice.dieroll()))
print("Die 2: " + str(dice.dieroll()))