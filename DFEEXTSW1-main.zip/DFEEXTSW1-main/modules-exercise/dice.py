from random import randint
def dieroll():
    return randint(1,6)