print("hello")


print()

str.join()

list.append()

sorted()

len()

str()
bool()
int()
float()