str1 = "this"
str2 = "that"

num1 = 3
num2 = 5

print(str1 + str2)  # concatenate
print(num1 + num2)  # mathematical addition

