import leonsfuncs

print(leonsfuncs.unknownlenght("dog","cat",7,"Space Mouse","Rock"))